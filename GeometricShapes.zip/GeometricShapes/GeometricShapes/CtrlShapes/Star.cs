﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometricShapes.CtrlShapes
{
    internal class Star
    {
        //clase propia de la estrella de 5 puntas

        //atributos de la estrella
        private double sideTriangle;
        private double heightTriangle;
        private double sidePentagon;
        //constructor de la estrella
        public Star(double sideTriangle, double heightTriangle)
        {
            this.sideTriangle = sideTriangle;
            this.heightTriangle = heightTriangle;
            this.sidePentagon = sideTriangle * 2.0 / Math.Tan(Math.PI / 5); // lado del pentágono
        }

        //metodo para calcular el area de la estrella
        public double? CalculateArea()
        {
            // Área de 5 triángulos (puntas)
            double areaTriangulo = (sideTriangle * heightTriangle) / 2.0;
            double areaPuntas = 5 * areaTriangulo;

            // Área del pentágono regular
            double cotangente36 = 1 / Math.Tan(Math.PI / 5); // cot(π/5)
            double areaPentagono = (5 * Math.Pow(sidePentagon, 2)) / 4.0 * cotangente36;

            // Área total
            return areaPuntas + areaPentagono;
        }
        //metodo para calcular el perimetro de la estrella
        public double? CalculatePerimeter()
        {
            return 10 * sideTriangle;
        }

        public bool ValidateInput()
        {
            // Verifica que el lado del triángulo y la altura sean mayores que cero
            if (sideTriangle <= 0 || heightTriangle <= 0)
            {
                return false;
            }
            return true;
        }


    }
}
