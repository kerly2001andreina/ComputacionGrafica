﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometricShapes.CtrlShapes
{
    internal class SemiCircle : BaseShape
    {
        //Clase propia del semicirculo
        private double radius;

        //constructor del semicirculo
        public SemiCircle(double radius)
        {
            this.radius = radius;
        }
        //metodo para calcular el area del semicirculo
        public double? CalculateArea()
        {
            return (Math.PI * Math.Pow(radius, 2)) / 2;
        }
        //metodo para calcular el perimetro del semicirculo
        public double? CalculatePerimeter()
        {
            return (Math.PI * radius) + (2 * radius);
        }
        public bool ValidateInput()
        {
            // Verifica que el radio sea mayor que cero
            if (radius <= 0)
            {
                return false;
            }
            return true;
        }

    }
}
