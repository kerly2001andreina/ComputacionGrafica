﻿namespace GeometricShapes.ModelShapes
{
    partial class UserCtrlStar
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpInputs = new System.Windows.Forms.GroupBox();
            this.lblSidePentagon = new System.Windows.Forms.Label();
            this.txtSidePentagon = new System.Windows.Forms.TextBox();
            this.lblHeightTriangle = new System.Windows.Forms.Label();
            this.txtHeightTriangle = new System.Windows.Forms.TextBox();
            this.lblSideTriangle = new System.Windows.Forms.Label();
            this.txtSideTriangle = new System.Windows.Forms.TextBox();
            this.grpInputs.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpInputs
            // 
            this.grpInputs.Controls.Add(this.lblSidePentagon);
            this.grpInputs.Controls.Add(this.txtSidePentagon);
            this.grpInputs.Controls.Add(this.lblHeightTriangle);
            this.grpInputs.Controls.Add(this.txtHeightTriangle);
            this.grpInputs.Controls.Add(this.lblSideTriangle);
            this.grpInputs.Controls.Add(this.txtSideTriangle);
            this.grpInputs.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.grpInputs.Location = new System.Drawing.Point(4, 5);
            this.grpInputs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grpInputs.Name = "grpInputs";
            this.grpInputs.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grpInputs.Size = new System.Drawing.Size(477, 225);
            this.grpInputs.TabIndex = 9;
            this.grpInputs.TabStop = false;
            this.grpInputs.Text = "Datos de Entrada";
            // 
            // lblSidePentagon
            // 
            this.lblSidePentagon.AutoSize = true;
            this.lblSidePentagon.Location = new System.Drawing.Point(33, 154);
            this.lblSidePentagon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSidePentagon.Name = "lblSidePentagon";
            this.lblSidePentagon.Size = new System.Drawing.Size(202, 28);
            this.lblSidePentagon.TabIndex = 8;
            this.lblSidePentagon.Text = "Lado Pentagono";
            // 
            // txtSidePentagon
            // 
            this.txtSidePentagon.Location = new System.Drawing.Point(270, 154);
            this.txtSidePentagon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSidePentagon.Name = "txtSidePentagon";
            this.txtSidePentagon.Size = new System.Drawing.Size(180, 37);
            this.txtSidePentagon.TabIndex = 7;
            // 
            // lblHeightTriangle
            // 
            this.lblHeightTriangle.AutoSize = true;
            this.lblHeightTriangle.Location = new System.Drawing.Point(33, 103);
            this.lblHeightTriangle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeightTriangle.Name = "lblHeightTriangle";
            this.lblHeightTriangle.Size = new System.Drawing.Size(193, 28);
            this.lblHeightTriangle.TabIndex = 6;
            this.lblHeightTriangle.Text = "Altura Triangulo";
            // 
            // txtHeightTriangle
            // 
            this.txtHeightTriangle.Location = new System.Drawing.Point(270, 103);
            this.txtHeightTriangle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHeightTriangle.Name = "txtHeightTriangle";
            this.txtHeightTriangle.Size = new System.Drawing.Size(180, 37);
            this.txtHeightTriangle.TabIndex = 5;
            // 
            // lblSideTriangle
            // 
            this.lblSideTriangle.AutoSize = true;
            this.lblSideTriangle.Location = new System.Drawing.Point(33, 52);
            this.lblSideTriangle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSideTriangle.Name = "lblSideTriangle";
            this.lblSideTriangle.Size = new System.Drawing.Size(182, 28);
            this.lblSideTriangle.TabIndex = 2;
            this.lblSideTriangle.Text = "Lado Triangulo";
            // 
            // txtSideTriangle
            // 
            this.txtSideTriangle.Location = new System.Drawing.Point(270, 52);
            this.txtSideTriangle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSideTriangle.Name = "txtSideTriangle";
            this.txtSideTriangle.Size = new System.Drawing.Size(180, 37);
            this.txtSideTriangle.TabIndex = 0;
            // 
            // UserCtrlStar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grpInputs);
            this.Name = "UserCtrlStar";
            this.Size = new System.Drawing.Size(517, 484);
            this.grpInputs.ResumeLayout(false);
            this.grpInputs.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpInputs;
        private System.Windows.Forms.Label lblSidePentagon;
        private System.Windows.Forms.TextBox txtSidePentagon;
        private System.Windows.Forms.Label lblHeightTriangle;
        private System.Windows.Forms.TextBox txtHeightTriangle;
        private System.Windows.Forms.Label lblSideTriangle;
        private System.Windows.Forms.TextBox txtSideTriangle;
    }
}
