﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GeometricShapes.CtrlShapes;
using GeometricShapes.Utility;

namespace GeometricShapes.ModelShapes
{
    public partial class UserCtrlSemiCircle : UserControl,BaseShape
    {
        //Variable para validar el numero positivo
        private double? validateValue = null;
        public UserCtrlSemiCircle()
        {
            InitializeComponent();

        }

        //metodo para calcular el area

        public double? CalculateArea()
        {
            SemiCircle semiCircle = new SemiCircle(validateValue.Value);
            return semiCircle.CalculateArea();
        }
        //metodo para calcular el perimetro
        public double? CalculatePerimeter()
        {
            SemiCircle semiCircle = new SemiCircle(validateValue.Value);
            return semiCircle.CalculatePerimeter();
        }
        public bool ValidateInput()
        {
            validateValue = FuncValidation.ValidatePositiveNumber(txtRadius, "Radio");
            return validateValue.HasValue;
        }

        private void txtRadius_TextChanged(object sender, EventArgs e)
        {
            validateValue = null;
        }
    }
}
