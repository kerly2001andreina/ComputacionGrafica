﻿namespace GeometricShapes.ModelShapes
{
    partial class UserCtrlIsoscelesTrapezium
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpInputs = new System.Windows.Forms.GroupBox();
            this.lblHeight = new System.Windows.Forms.Label();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.lblMinorBase = new System.Windows.Forms.Label();
            this.txtMinorBase = new System.Windows.Forms.TextBox();
            this.lblMajorBase = new System.Windows.Forms.Label();
            this.txtMajorBase = new System.Windows.Forms.TextBox();
            this.grpInputs.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpInputs
            // 
            this.grpInputs.Controls.Add(this.lblHeight);
            this.grpInputs.Controls.Add(this.txtHeight);
            this.grpInputs.Controls.Add(this.lblMinorBase);
            this.grpInputs.Controls.Add(this.txtMinorBase);
            this.grpInputs.Controls.Add(this.lblMajorBase);
            this.grpInputs.Controls.Add(this.txtMajorBase);
            this.grpInputs.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.grpInputs.Location = new System.Drawing.Point(4, 5);
            this.grpInputs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grpInputs.Name = "grpInputs";
            this.grpInputs.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grpInputs.Size = new System.Drawing.Size(477, 225);
            this.grpInputs.TabIndex = 8;
            this.grpInputs.TabStop = false;
            this.grpInputs.Text = "Datos de Entrada";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(33, 154);
            this.lblHeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(81, 28);
            this.lblHeight.TabIndex = 8;
            this.lblHeight.Text = "Altura";
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(270, 154);
            this.txtHeight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(180, 37);
            this.txtHeight.TabIndex = 7;
            // 
            // lblMinorBase
            // 
            this.lblMinorBase.AutoSize = true;
            this.lblMinorBase.Location = new System.Drawing.Point(33, 103);
            this.lblMinorBase.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMinorBase.Name = "lblMinorBase";
            this.lblMinorBase.Size = new System.Drawing.Size(150, 28);
            this.lblMinorBase.TabIndex = 6;
            this.lblMinorBase.Text = "Base menor";
            // 
            // txtMinorBase
            // 
            this.txtMinorBase.Location = new System.Drawing.Point(270, 103);
            this.txtMinorBase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMinorBase.Name = "txtMinorBase";
            this.txtMinorBase.Size = new System.Drawing.Size(180, 37);
            this.txtMinorBase.TabIndex = 5;
            // 
            // lblMajorBase
            // 
            this.lblMajorBase.AutoSize = true;
            this.lblMajorBase.Location = new System.Drawing.Point(33, 52);
            this.lblMajorBase.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMajorBase.Name = "lblMajorBase";
            this.lblMajorBase.Size = new System.Drawing.Size(151, 28);
            this.lblMajorBase.TabIndex = 2;
            this.lblMajorBase.Text = "Base mayor";
            // 
            // txtMajorBase
            // 
            this.txtMajorBase.Location = new System.Drawing.Point(270, 52);
            this.txtMajorBase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMajorBase.Name = "txtMajorBase";
            this.txtMajorBase.Size = new System.Drawing.Size(180, 37);
            this.txtMajorBase.TabIndex = 0;
            // 
            // UserCtrlIsoscelesTrapezium
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grpInputs);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "UserCtrlIsoscelesTrapezium";
            this.Size = new System.Drawing.Size(501, 492);
            this.grpInputs.ResumeLayout(false);
            this.grpInputs.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpInputs;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.Label lblMinorBase;
        private System.Windows.Forms.TextBox txtMinorBase;
        private System.Windows.Forms.Label lblMajorBase;
        private System.Windows.Forms.TextBox txtMajorBase;
    }
}
