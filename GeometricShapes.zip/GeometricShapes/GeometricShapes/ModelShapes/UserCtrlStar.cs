﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GeometricShapes.CtrlShapes;
using GeometricShapes.Utility;

namespace GeometricShapes.ModelShapes
{
    public partial class UserCtrlStar : UserControl, BaseShape
    {
        //Variable para validar el numero positivo
        private double? validateValue = null;
        public UserCtrlStar()
        {
            InitializeComponent();
        }
        //metodo para calcular el area
        public double? CalculateArea()
        {
            if( double.TryParse(txtSideTriangle.Text, out double sideTriangle) && double.TryParse(txtHeightTriangle.Text, out double heightTriangle))
            {
                Star star = new Star(sideTriangle, heightTriangle);
                return star.CalculateArea();
            }
            return null;
        }
        //metodo para calcular el perimetro
        public double? CalculatePerimeter()
        {
            if (double.TryParse(txtSideTriangle.Text, out double sideTriangle) && double.TryParse(txtHeightTriangle.Text, out double heightTriangle))
            {
                Star star = new Star(sideTriangle, heightTriangle);
                return star.CalculatePerimeter();
            }
            return null;
        }
        public bool ValidateInput()
        {
            validateValue = FuncValidation.ValidatePositiveNumber(txtSideTriangle, "Lado");
            if (validateValue.HasValue)
            {
                validateValue = FuncValidation.ValidatePositiveNumber(txtHeightTriangle, "Altura");
            }
            return validateValue.HasValue;
        }
    }
}
